import React from 'react'
import Card from '../Views/Card'
import Search from '../Views/Search'

export default function Home() {
  return (
    <>
    <Search/>
      <Card />
      </>
  )
}
